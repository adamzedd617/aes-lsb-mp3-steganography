import os
import wave
import base64
import secrets
import numpy as np
import soundfile as sf
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from utils.logging_util import setup_logger

logger = setup_logger(__name__)

# === AES-256 Encryption Utility ===
def generate_aes_key():
    return secrets.token_bytes(32)

def encrypt_message(message, key):
    iv = secrets.token_bytes(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).encryptor()

    if isinstance(message, str):
        message = message.encode()  # Convert string to bytes

    padder = padding.PKCS7(128).padder()  # Ensure block size is 16 bytes (128 bits)
    padded_message = padder.update(message) + padder.finalize()
    
    ciphertext = cipher.update(padded_message) + cipher.finalize()
    return iv + ciphertext  # Return IV + encrypted data as bytes


def decrypt_message(encrypted_message, key):
    try:
        if len(encrypted_message) < 16:
            raise ValueError("Decryption error: Encrypted message is too short.")

        iv, ciphertext = encrypted_message[:16], encrypted_message[16:]  # Extract IV correctly

        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).decryptor()
        decrypted_padded = cipher.update(ciphertext) + cipher.finalize()

        # Remove padding
        unpadder = padding.PKCS7(128).unpadder()
        decrypted = unpadder.update(decrypted_padded) + unpadder.finalize()

        return decrypted.decode('utf-8', errors='ignore')  # Ensure valid string output

    except Exception as e:
        logger.error(f"Decryption failed: {e}")
        return "[DECRYPTION ERROR]"




# Secure AES Key (Should be stored securely)
AES_KEY = generate_aes_key()

# === LSB Encoding & Decoding ===
def lsb_encode(input_audio, output_audio, message):
    encrypted_message = encrypt_message(message, AES_KEY)  # Now returns bytes
    encrypted_message += b'###'  # Append delimiter in bytes

    with wave.open(input_audio, 'rb') as audio:
        frame_bytes = bytearray(audio.readframes(audio.getnframes()))

    # Convert encrypted message bytes to bits
    message_bits = ''.join(format(byte, '08b') for byte in encrypted_message)

    if len(message_bits) > len(frame_bytes):
        raise ValueError("Message is too long to encode!")

    for i in range(len(message_bits)):
        frame_bytes[i] = (frame_bytes[i] & 254) | int(message_bits[i])

    with wave.open(output_audio, 'wb') as new_audio:
        new_audio.setparams(audio.getparams())
        new_audio.writeframes(bytes(frame_bytes))

    logger.info("Encoding Complete!")


def lsb_decode(input_audio):
    with wave.open(input_audio, 'rb') as audio:
        frame_bytes = bytearray(audio.readframes(audio.getnframes()))

    message_bits = ''.join(str(byte & 1) for byte in frame_bytes)
    extracted_bytes = bytes(int(message_bits[i:i+8], 2) for i in range(0, len(message_bits), 8))

    # Ensure extracted bytes contain the delimiter
    if b'###' in extracted_bytes:
        encrypted_message = extracted_bytes.split(b'###')[0]  # Extract encrypted bytes
    else:
        logger.error("Decoding error: Delimiter not found.")
        return "[DECODING ERROR]"

    decrypted_message = decrypt_message(encrypted_message, AES_KEY)  # Ensure correct decryption

    print(f"\n🔹 Decoded Message: {decrypted_message}")  # Print decoded message
    return decrypted_message


# === Advanced LSB Encoding & Decoding ===
def lsb_advanced_encode(input_audio, output_audio, message):
    encrypted_message = encrypt_message(message, AES_KEY)  # Returns bytes
    encrypted_message += b'###'  # Convert delimiter to bytes

    with wave.open(input_audio, 'rb') as audio:
        frame_bytes = bytearray(audio.readframes(audio.getnframes()))

    # Convert encrypted bytes to bits
    message_bits = ''.join(format(byte, '08b') for byte in encrypted_message)

    if len(message_bits) > len(frame_bytes):
        raise ValueError("Message is too long to encode!")

    for i in range(0, len(message_bits), 2):  # Encode in pairs for better robustness
        frame_bytes[i] = (frame_bytes[i] & 254) | int(message_bits[i])
        if i + 1 < len(message_bits):
            frame_bytes[i + 1] = (frame_bytes[i + 1] & 254) | int(message_bits[i + 1])

    with wave.open(output_audio, 'wb') as new_audio:
        new_audio.setparams(audio.getparams())
        new_audio.writeframes(bytes(frame_bytes))

    logger.info("Advanced Encoding Complete!")


def lsb_advanced_decode(input_audio):
    with wave.open(input_audio, 'rb') as audio:
        frame_bytes = bytearray(audio.readframes(audio.getnframes()))
    
    message_bits = ''.join(str(byte & 1) for byte in frame_bytes)
    extracted_message = ''.join(chr(int(message_bits[i:i+8], 2)) for i in range(0, len(message_bits), 8))
    
    encrypted_message = extracted_message.split('###')[0]
    return decrypt_message(encrypted_message, AES_KEY)

# Algorithm Registry
lsb_algorithms = [
    {"name": "Basic LSB with AES", "encode": lsb_encode, "decode": lsb_decode},
    {"name": "Advanced LSB with AES", "encode": lsb_advanced_encode, "decode": lsb_advanced_decode},
]

logger.info("AES-256 encryption integrated into both Basic and Advanced LSB encoding!")
